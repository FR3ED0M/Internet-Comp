Font usage: Demo only
Font by: Roland Huse & Font Monger
Distributed by: Font Monger

This font may not be used commercially, monetized, or in media without permission. This font is for personal purposes only.


Without Font Premission:
You may not edit this font
You may not rename this font
You may not repackage, distribute, or sale this font
You may not use this font in multimeda, tv, applications, video games, or film.


For a commercial use license visit:
http://www.fontmonger.com


For accents, european, and special characters contact: info@fontmonger.com

