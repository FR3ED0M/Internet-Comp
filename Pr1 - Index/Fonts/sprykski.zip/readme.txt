Sprykski - readme. 

This alien script appears in the PC videogame Spryke (www.sprykegame.com)

Usage of this font is free for non-commercial use. For commercial use, contact Volnaiskra at www.volnaiskra.com/contact.html